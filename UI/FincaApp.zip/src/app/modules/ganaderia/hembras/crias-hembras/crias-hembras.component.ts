import { Component } from '@angular/core';

@Component({
  selector: 'app-crias-hembras',
  imports: [],
  templateUrl: './crias-hembras.component.html',
  styleUrl: './crias-hembras.component.css'
})
export class CriasHembrasComponent {

}
