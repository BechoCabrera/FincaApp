import { Component } from '@angular/core';

@Component({
  selector: 'app-escotera',
  imports: [],
  templateUrl: './escotera.component.html',
  styleUrl: './escotera.component.css'
})
export class EscoteraComponent {

}
