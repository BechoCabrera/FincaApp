import { Component } from '@angular/core';

@Component({
  selector: 'app-novillas-vientre',
  imports: [],
  templateUrl: './novillas-vientre.component.html',
  styleUrl: './novillas-vientre.component.css'
})
export class NovillasVientreComponent {

}
