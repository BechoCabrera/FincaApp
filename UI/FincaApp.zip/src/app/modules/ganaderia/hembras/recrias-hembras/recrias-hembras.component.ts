import { Component } from '@angular/core';

@Component({
  selector: 'app-recrias-hembras',
  imports: [],
  templateUrl: './recrias-hembras.component.html',
  styleUrl: './recrias-hembras.component.css'
})
export class RecriasHembrasComponent {

}
