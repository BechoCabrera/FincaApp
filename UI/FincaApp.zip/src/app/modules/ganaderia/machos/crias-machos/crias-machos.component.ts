import { Component } from '@angular/core';

@Component({
  selector: 'app-crias-machos',
  imports: [],
  templateUrl: './crias-machos.component.html',
  styleUrl: './crias-machos.component.css'
})
export class CriasMachosComponent {

}
