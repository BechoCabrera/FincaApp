import { Component } from '@angular/core';

@Component({
  selector: 'app-recrias-machos',
  imports: [],
  templateUrl: './recrias-machos.component.html',
  styleUrl: './recrias-machos.component.css'
})
export class RecriasMachosComponent {

}
