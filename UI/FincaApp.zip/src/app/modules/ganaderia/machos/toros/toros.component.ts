import { Component } from '@angular/core';

@Component({
  selector: 'app-toros',
  imports: [],
  templateUrl: './toros.component.html',
  styleUrl: './toros.component.css'
})
export class TorosComponent {

}
