import { Component } from '@angular/core';

@Component({
  selector: 'app-toretes',
  imports: [],
  templateUrl: './toretes.component.html',
  styleUrl: './toretes.component.css'
})
export class ToretesComponent {

}
