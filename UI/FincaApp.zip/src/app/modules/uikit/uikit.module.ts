import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UikitRoutingModule } from './uikit-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    UikitRoutingModule
  ]
})
export class UikitModule { }
