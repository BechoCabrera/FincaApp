export interface Theme {
  mode: string;
  color: string;
  direction: string;
}
