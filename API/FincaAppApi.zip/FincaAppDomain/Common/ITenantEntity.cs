﻿namespace FincaAppDomain.Common;

public interface ITenantEntity
{
    string TenantId { get; set; }
}
